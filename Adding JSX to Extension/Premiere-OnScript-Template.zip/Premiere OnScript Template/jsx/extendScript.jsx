
$.runScript = {


	changeThisFunctionName: function() {
	//--------------------------------------------------------------------------------------------------------------------------------------------------
		//Copy/Paste your script from Adobe Extendscript HERE!!!!
		alert("Please find and read the ReadMe.txt file for instruction on how to use this panel template.")
	//--------------------------------------------------------------------------------------------------------------------------------------------------
}	
    
}